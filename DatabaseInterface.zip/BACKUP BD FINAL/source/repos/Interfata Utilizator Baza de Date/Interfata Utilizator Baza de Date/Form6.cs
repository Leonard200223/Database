﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfata_Utilizator_Baza_de_Date
{
    public partial class Form6 : Form
    {

        private ResultsForm? resultsForm;
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT * " +
                                          "FROM Cumparator";

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ResultsForm_FormClosed(object? sender, FormClosedEventArgs e)
        {
            if (resultsForm != null)
            {
                resultsForm = null; // Set it to null to create a new instance on the next run
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT * " +
                                          "FROM Bilet";

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT * " +
                                          "FROM Concert";

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT * " +
                                          "FROM Artist";

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT * " +
                                          "FROM Localitate";

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT * " +
                                          "FROM ConcertLocalitate";

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT * " +
                                          "FROM ArtistConcert";

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
