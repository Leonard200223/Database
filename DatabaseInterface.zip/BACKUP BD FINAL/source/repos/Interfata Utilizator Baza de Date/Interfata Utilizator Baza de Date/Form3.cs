﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Interfata_Utilizator_Baza_de_Date
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "INSERT INTO Artist (Nume, Prenume, TipMuzica) VALUES (@Nume, @Prenume, @TipMuzica)";

                        // Set parameter values from textboxes
                        cmd.Parameters.AddWithValue("@Nume", textBox1.Text);
                        cmd.Parameters.AddWithValue("@Prenume", textBox2.Text);
                        cmd.Parameters.AddWithValue("@TipMuzica", textBox3.Text);


                        // Execute the query
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Row added successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Failed to add row", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "DELETE FROM Artist WHERE (Nume = @Nume AND Prenume IS NULL) OR (Nume = @Nume AND Prenume = @Prenume)";

                        // Set parameter value from the delete textbox
                        cmd.Parameters.AddWithValue("@Nume", textBox6.Text);
                        cmd.Parameters.AddWithValue("@Prenume", textBox4.Text);

                        // Execute the query
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Row deleted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No matching rows found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "UPDATE Artist SET Nume = @Nume, Prenume = @Prenume, TipMuzica = @TipMuzica WHERE (Nume = @Nume2 AND Prenume IS NULL) OR (Nume = @Nume2 AND Prenume = @Prenume2)";

                        // Set parameter values from the edit textboxes
                        cmd.Parameters.AddWithValue("@Nume", textBox9.Text);
                        cmd.Parameters.AddWithValue("@Prenume", textBox8.Text);
                        cmd.Parameters.AddWithValue("@TipMuzica", textBox7.Text);


                        // Set the parameter value for the old phone number
                        cmd.Parameters.AddWithValue("@Nume2", textBox12.Text); // Change this if you want to edit based on a different column
                        cmd.Parameters.AddWithValue("@Prenume2", textBox11.Text);

                        // Execute the query
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Row updated successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No matching rows found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
