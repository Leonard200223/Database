﻿namespace Interfata_Utilizator_Baza_de_Date
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label8 = new Label();
            label6 = new Label();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            textBox4 = new TextBox();
            textBox6 = new TextBox();
            label5 = new Label();
            label9 = new Label();
            textBox11 = new TextBox();
            textBox12 = new TextBox();
            label14 = new Label();
            label15 = new Label();
            SuspendLayout();
            // 
            // textBox7
            // 
            textBox7.Location = new Point(89, 393);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(272, 23);
            textBox7.TabIndex = 42;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(89, 361);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(272, 23);
            textBox8.TabIndex = 41;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(89, 330);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(272, 23);
            textBox9.TabIndex = 40;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(19, 401);
            label10.Name = "label10";
            label10.Size = new Size(64, 15);
            label10.TabIndex = 38;
            label10.Text = "Tip Muzica";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(19, 369);
            label11.Name = "label11";
            label11.Size = new Size(55, 15);
            label11.TabIndex = 37;
            label11.Text = "Prenume";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(19, 338);
            label12.Name = "label12";
            label12.Size = new Size(40, 15);
            label12.TabIndex = 36;
            label12.Text = "Nume";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(19, 312);
            label8.Name = "label8";
            label8.Size = new Size(74, 15);
            label8.TabIndex = 35;
            label8.Text = "Editare Artist";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(19, 182);
            label6.Name = "label6";
            label6.Size = new Size(87, 15);
            label6.TabIndex = 32;
            label6.Text = "Eliminare Artist";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(89, 100);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(272, 23);
            textBox3.TabIndex = 30;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(89, 68);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(272, 23);
            textBox2.TabIndex = 29;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(89, 37);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(272, 23);
            textBox1.TabIndex = 28;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(19, 108);
            label4.Name = "label4";
            label4.Size = new Size(64, 15);
            label4.TabIndex = 26;
            label4.Text = "Tip Muzica";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(19, 76);
            label3.Name = "label3";
            label3.Size = new Size(55, 15);
            label3.TabIndex = 25;
            label3.Text = "Prenume";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(19, 45);
            label2.Name = "label2";
            label2.Size = new Size(40, 15);
            label2.TabIndex = 24;
            label2.Text = "Nume";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 16);
            label1.Name = "label1";
            label1.Size = new Size(89, 15);
            label1.TabIndex = 23;
            label1.Text = "Adaugare Artist";
            // 
            // button3
            // 
            button3.Location = new Point(577, 230);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 48;
            button3.Text = "Editare";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(577, 201);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 47;
            button2.Text = "Eliminare";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(577, 172);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 46;
            button1.Text = "Adaugare";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(89, 231);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(272, 23);
            textBox4.TabIndex = 52;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(89, 200);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(272, 23);
            textBox6.TabIndex = 51;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(19, 239);
            label5.Name = "label5";
            label5.Size = new Size(55, 15);
            label5.TabIndex = 50;
            label5.Text = "Prenume";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(19, 208);
            label9.Name = "label9";
            label9.Size = new Size(40, 15);
            label9.TabIndex = 49;
            label9.Text = "Nume";
            // 
            // textBox11
            // 
            textBox11.Location = new Point(516, 361);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(272, 23);
            textBox11.TabIndex = 54;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(516, 330);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(272, 23);
            textBox12.TabIndex = 53;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(428, 338);
            label14.Name = "label14";
            label14.Size = new Size(71, 15);
            label14.TabIndex = 55;
            label14.Text = "Nume Vechi";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(428, 369);
            label15.Name = "label15";
            label15.Size = new Size(86, 15);
            label15.TabIndex = 56;
            label15.Text = "Prenume Vechi";
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(textBox11);
            Controls.Add(textBox12);
            Controls.Add(textBox4);
            Controls.Add(textBox6);
            Controls.Add(label5);
            Controls.Add(label9);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox7);
            Controls.Add(textBox8);
            Controls.Add(textBox9);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label8);
            Controls.Add(label6);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form3";
            Text = "Adaugare, eliminare sau editare Artist";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label8;
        private Label label6;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button button3;
        private Button button2;
        private Button button1;
        private TextBox textBox4;
        private TextBox textBox6;
        private Label label5;
        private Label label9;
        private TextBox textBox11;
        private TextBox textBox12;
        private Label label14;
        private Label label15;
    }
}