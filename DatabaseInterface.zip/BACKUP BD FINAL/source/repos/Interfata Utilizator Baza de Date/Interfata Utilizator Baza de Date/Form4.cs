﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Interfata_Utilizator_Baza_de_Date
{
    public partial class Form4 : Form
    {

        private ResultsForm? resultsForm;

        public Form4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT Concert.ConcertID, Concert.NumeConcert, Artist.Nume, Artist.Prenume " +
                                          "FROM Concert " +
                                          "INNER JOIN ArtistConcert ON Concert.ConcertID = ArtistConcert.ConcertID " +
                                          "INNER JOIN Artist ON ArtistConcert.ArtistID = Artist.ArtistID";

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ResultsForm_FormClosed(object? sender, FormClosedEventArgs e)
        {
            if (resultsForm != null)
            {
                resultsForm = null; // Set it to null to create a new instance on the next run
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT Cumparator.Nume, Cumparator.Prenume, Concert.NumeConcert, Bilet.Data " +
                                          "FROM Cumparator " +
                                          "INNER JOIN Bilet ON Cumparator.CumparatorID = Bilet.CumparatorID " +
                                          "INNER JOIN Concert ON Bilet.ConcertID = Concert.ConcertID";

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT Concert.NumeConcert, Concert.DataInceput, Concert.DataSfarsit, Localitate.Denumire, Localitate.Judet " +
                                          "FROM Concert " +
                                          "INNER JOIN ConcertLocalitate ON Concert.ConcertID = ConcertLocalitate.ConcertID " +
                                          "INNER JOIN Localitate ON ConcertLocalitate.LocalitateID = Localitate.LocalitateID";

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT Concert.ConcertID, Concert.NumeConcert, Artist.Nume, Artist.Prenume, ArtistConcert.NumarPiese " +
                                          "FROM Concert " +
                                          "INNER JOIN ArtistConcert ON Concert.ConcertID = ArtistConcert.ConcertID " +
                                          "INNER JOIN Artist ON ArtistConcert.ArtistID = Artist.ArtistID";

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT Bilet.BiletID, Bilet.Data, Bilet.Pret, Bilet.NumarLoc, Cumparator.Nume, Cumparator.Prenume, Concert.NumeConcert " +
                                          "FROM Bilet " +
                                          "INNER JOIN Cumparator ON Bilet.CumparatorID = Cumparator.CumparatorID " +
                                          "INNER JOIN Concert ON Bilet.ConcertID = Concert.ConcertID";

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT Concert.NumeConcert, Artist.Nume, Artist.Prenume, Localitate.Judet " +
                                          "FROM Concert " +
                                          "INNER JOIN ConcertLocalitate ON Concert.ConcertID = ConcertLocalitate.ConcertID " +
                                          "INNER JOIN Localitate ON ConcertLocalitate.LocalitateID = Localitate.LocalitateID " +
                                          "INNER JOIN ArtistConcert ON Concert.ConcertID = ArtistConcert.ConcertID " +
                                          "INNER JOIN Artist ON ArtistConcert.ArtistID = Artist.ArtistID " +
                                          "WHERE Localitate.Judet = @Judet";

                        cmd.Parameters.AddWithValue("@Judet", textBox1.Text);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
