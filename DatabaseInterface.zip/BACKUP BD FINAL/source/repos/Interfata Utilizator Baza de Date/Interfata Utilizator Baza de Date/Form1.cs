using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Interfata_Utilizator_Baza_de_Date
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection();
        SqlCommand com = new SqlCommand();
        public Form1()
        {
            InitializeComponent();
            con.ConnectionString = @"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUserEnter(object sender, EventArgs e)
        {
            if (txtUsername.Text.Equals(@"Username\E-mail"))
            {
                txtUsername.Text = "";
            }
        }

        private void txtUserLeave(object sender, EventArgs e)
        {
            if (txtUsername.Text.Equals(""))
            {
                txtUsername.Text = @"Username\E-mail";
            }
        }

        private void txtPassEnter(object sender, EventArgs e)
        {
            if (txtPassword.Text.Equals("Password"))
            {
                txtPassword.Text = "";
            }
        }

        private void txtPassLeave(object sender, EventArgs e)
        {
            if (txtPassword.Text.Equals(""))
            {
                txtPassword.Text = "Password";
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                com.Connection = con;
                com.CommandText = "select * from AUTH";
                SqlDataReader dr = com.ExecuteReader();

                bool found = false;

                while (dr.Read())
                {
                    if (txtUsername.Text.Equals(dr["username"].ToString()) && txtPassword.Text.Equals(dr["password"].ToString()))
                    {
                        found = true;
                        break;
                    }
                }

                con.Close();

                if (found)
                {
                    MessageBox.Show("Login Successfully", "Congrats", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Open the AdminDashboardForm and hide the current login form
                    Form2 adminDashboardForm = new Form2();
                    adminDashboardForm.Show();
                    Form3 adminDashboardForm2 = new Form3();
                    adminDashboardForm2.Show();
                    Form4 adminDashboardForm3 = new Form4();
                    adminDashboardForm3.Show();
                    Form5 adminDashboardForm4 = new Form5();
                    adminDashboardForm4.Show();
                    Form6 adminDashboardForm5 = new Form6();
                    adminDashboardForm5.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Either your username or password is incorrect", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}