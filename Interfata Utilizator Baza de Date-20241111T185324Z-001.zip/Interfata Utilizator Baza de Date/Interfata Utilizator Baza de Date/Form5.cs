﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Interfata_Utilizator_Baza_de_Date
{
    public partial class Form5 : Form
    {

        private ResultsForm? resultsForm;
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT Concert.NumeConcert, COUNT(Bilet.BiletID) AS NumarParticipanti " +
                                          "FROM Concert " +
                                          "LEFT JOIN Bilet ON Concert.ConcertID = Bilet.ConcertID " +
                                          "GROUP BY Concert.NumeConcert " +
                                          "HAVING COUNT(Bilet.BiletID) = ( " +
                                          "SELECT MAX(NumarParticipanti) " +
                                          "FROM ( " +
                                          "SELECT ConcertID, COUNT(BiletID) AS NumarParticipanti " +
                                          "FROM Bilet " +
                                          "GROUP BY ConcertID " +
                                          ") AS ParticipantiConcert " +
                                          ") ";



                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ResultsForm_FormClosed(object? sender, FormClosedEventArgs e)
        {
            if (resultsForm != null)
            {
                resultsForm = null; // Set it to null to create a new instance on the next run
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT Concert.NumeConcert, AVG(Bilet.Pret) AS AvgTicketPrice " +
                                          "FROM Concert " +
                                          "LEFT JOIN Bilet ON Concert.ConcertID = Bilet.ConcertID " +
                                          "GROUP BY Concert.NumeConcert " +
                                          "HAVING AVG(Bilet.Pret) > (SELECT AVG(Pret) FROM Bilet) ";

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT DISTINCT AltCumparator.Nume, AltCumparator.Prenume " +
                                          "FROM Bilet AS BiletPrincipal " +
                                          "INNER JOIN Cumparator AS CumparatorPrincipal ON BiletPrincipal.CumparatorID = CumparatorPrincipal.CumparatorID " +
                                          "INNER JOIN ( " +
                                          "SELECT Bilet.ConcertID, Cumparator.CumparatorID " +
                                          "FROM Bilet " +
                                          "INNER JOIN Cumparator ON Bilet.CumparatorID = Cumparator.CumparatorID " +
                                          "WHERE Cumparator.CNP = @CNP " +
                                          ") AS Subquery ON BiletPrincipal.ConcertID = Subquery.ConcertID " +
                                          "INNER JOIN Bilet AS AltBilet ON BiletPrincipal.ConcertID = AltBilet.ConcertID " +
                                          "INNER JOIN Cumparator AS AltCumparator ON AltBilet.CumparatorID = AltCumparator.CumparatorID";

                        cmd.Parameters.AddWithValue("@CNP", textBox1.Text);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-EV1SM1J\SQLEXPRESS;Initial Catalog=Proiect_Nuta_Leonard_Florian_333AA;Integrated Security=True"))
                {
                    connection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandText = "SELECT Concert.NumeConcert " +
                                          "FROM Concert " +
                                          "INNER JOIN ArtistConcert ON Concert.ConcertID = ArtistConcert.ConcertID " +
                                          "WHERE ArtistConcert.NumarPiese > (SELECT AVG(NumarPiese) FROM ArtistConcert) ";

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if ResultsForm is null or disposed
                            if (resultsForm == null || resultsForm.IsDisposed)
                            {
                                resultsForm = new ResultsForm();
                                resultsForm.FormClosed += ResultsForm_FormClosed; // Subscribe to FormClosed event
                            }

                            // Clear previous data in the DataGridView
                            resultsForm.dataGridViewResults.Rows.Clear();
                            resultsForm.dataGridViewResults.Columns.Clear();

                            // Add column headers to the DataGridView
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                resultsForm.dataGridViewResults.Columns.Add(reader.GetName(i), reader.GetName(i));
                            }

                            // Populate the DataGridView with data
                            while (reader.Read())
                            {
                                object[] rowData = new object[reader.FieldCount];
                                reader.GetValues(rowData);
                                resultsForm.dataGridViewResults.Rows.Add(rowData);
                            }

                            // Show ResultsForm
                            if (!resultsForm.Visible)
                            {
                                resultsForm.Show();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
